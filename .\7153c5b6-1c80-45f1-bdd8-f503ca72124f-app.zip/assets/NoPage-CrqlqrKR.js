import{Y as o}from"./index-oZzaTV2f.js";function e(){return o.jsx("h1",{children:"404"})}e.displayName="NoPage";export{e as Component};
