import{Y as o}from"./index-DjUOHBSj.js";function e(){return o.jsx("h1",{children:"404"})}e.displayName="NoPage";export{e as Component};
